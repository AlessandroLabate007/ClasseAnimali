﻿namespace Animali
{
    internal class Program
    {
        static void Main(string[] args)
        {
            CCane cane = new CCane(6,7,"sessantasette");
            Console.WriteLine(cane.ToString());
            Console.WriteLine(cane.Verso());

        }
    }
}
